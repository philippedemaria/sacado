define(['jquery', 'ui'], function ($) {
    $(function () {
        $("#sortable-item").sortable();
    });
});